from django.shortcuts import render
from proyecto.models import Proyecto

def proyecto_index(request):
    proyecto = Proyecto.objects.all()
    context = {
        'proyecto': proyecto
    }
    return render(request, 'proyecto_index.html', context)

def proyecto_detail(request, pk):
    p= Proyecto.objects.get(pk=pk)
    context = {
        'p': p
    }
    return render(request, 'proyecto_detail.html', context)
def home(request):
    return render(request, 'home.html', {})

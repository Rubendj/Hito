from django.urls import path
from . import views

urlpatterns = [
    path("proyecto/", views.proyecto_index, name="proyecto_index"),
    path("<int:pk>/", views.proyecto_detail, name="proyecto_detail"),
    path("", views.home, name="home"),
]
from django.shortcuts import render

def hito(request):
    return render(request, 'hito.html', {})

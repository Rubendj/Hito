from django.urls import path
from hito import views

urlpatterns = [
    path('', views.hito, name='hito'),
]
from django.apps import AppConfig


class HitoConfig(AppConfig):
    name = 'hito'
